package sbdproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/*
    klasa odpowiadająca za przeglądanie i ewenetualną edycję kursu
*/

public class FXMLeditcourseController implements Initializable {
    
    private Boolean authorView = false;
    
    @FXML
    private TextField fld_l_title;
    @FXML
    private TextField fld_c_title;
    @FXML
    private TextArea txta_lesson;
    @FXML
    private TextArea txta_course;
    @FXML
    private Label lbl_lesson;
    
    @FXML
    private void prevLesson(ActionEvent event) {
        if(lesson_ordinal > 0) {
            lesson_ordinal -= 1;
            displayLesson();
        }
    }
    
    @FXML
    private void nextLesson(ActionEvent event) {
        if(lesson_ordinal < lessons.size() - 1) {
            lesson_ordinal += 1;
            if(!authorView && max_bought < lessons.get(lesson_ordinal).getOrdinal())
                lesson_ordinal -= 1;
            else
                displayLesson();
        }
    }
    
    @FXML
    private void getBack(ActionEvent event) {
        DBcontrol.context_course = null;
        SBDproject.changeScene(getClass(), "FXMLsearchpanel.fxml", event);
    }
    
    @FXML
    private void updateLesson(ActionEvent event) {
        
    }
    
    @FXML
    private void insertLesson(ActionEvent event) {
        
    }
    
    @FXML
    private void deleteLesson(ActionEvent event) {
    }
    
    private Integer lesson_ordinal = 0;
    private Integer max_bought = 0;
    private void displayLesson() {
        System.out.println("size " + lessons.size());
        System.out.println("max_bought " + max_bought);
        
        if(lessons == null) return;
        Lesson temp = lessons.get(lesson_ordinal);
        if(temp == null) return;
        if(authorView) {
            lbl_cost.setText(String.valueOf(temp.getPrice()));
        }
        txta_lesson.setText(temp.getContent());
        fld_l_title.setText(temp.getTitle());
        lbl_lesson.setText("Lesson " + temp.getOrdinal() + 1);
    }
    
    @FXML
    private Button btn_insert;
    @FXML
    private Button btn_delete;
    @FXML
    private Button btn_update;
    @FXML
    private TextField fld_cost;
    @FXML
    private Label lbl_cost;
    
    
    private ArrayList<Lesson> lessons = null;
    private final String PSfetch = "select * from sbd_tutor.lesson"
            + " where cat = ? and course = ? order by ordinal asc";
    private final String PSupdate = "update sbd_tutor.lesson set title = ?, content = ?, price = ?"
            + " where cat = ? and course = ? and ordinal = ?";
    private final String PSdelete = "delete from sbd_tutor.lesson where"
            + " cat = ? and course = ? and ordinal = ?";
    private final String PSinsert = "insert into sbd_tutor.lesson values"
            + "(?, ?, ?, ?, ?, ?)";
    private final String PSmax = "select * from sbd_tutor.payments"
            + " where user =? and cat=? and course=? order by lessons desc";
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        DBstatement.initStates();
        DBstatement.prepState(PSfetch);
        DBstatement.prepState(PSdelete);
        DBstatement.prepState(PSinsert);
        DBstatement.prepState(PSupdate);
        DBstatement.prepState(PSmax);
        txta_course.setEditable(false);
        fld_c_title.setEditable(false);
        if(DBcontrol.context_course != null && DBcontrol.context_user != null) {
            fld_c_title.setText(DBcontrol.context_course.getTitle());
            txta_course.setText(DBcontrol.context_course.getDescritpion());
            if(DBcontrol.context_course.getAuthor().equals(DBcontrol.context_user.getName())) {
                authorView = true;
            } else {
                btn_insert.setVisible(false);
                btn_update.setVisible(false);
                btn_delete.setVisible(false);
                fld_cost.setVisible(false);
                lbl_cost.setVisible(false);
                txta_lesson.setEditable(false);
                fld_l_title.setEditable(false);
            }
            ArrayList<DBstatement.arg> args = new ArrayList<>();
            args.add(new DBstatement.arg(DBcontrol.context_course.getCat(), null, null));
            args.add(new DBstatement.arg(DBcontrol.context_course.getTitle(), null, null));
            lessons = DBstatement.execFetch("lesson", 0, args);


            ArrayList<DBstatement.arg> args2 = new ArrayList<>();
            args2.add(new DBstatement.arg(DBcontrol.context_user.getName(), null, null));
            args2.add(new DBstatement.arg(DBcontrol.context_course.getCat(), null, null));
            args2.add(new DBstatement.arg(DBcontrol.context_course.getTitle(), null, null));
            ArrayList<Payment> pmt = DBstatement.execFetch("payment", 4, args2);
            if(pmt != null) {
                max_bought = pmt.get(0).getLessons();
                displayLesson();
            }
        }
    }    
    
}
