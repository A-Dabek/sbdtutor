package sbdproject;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;

/*
    klasa odpowiedzialna za panel wyszukiwania kursów
*/

public class FXMLsearchpanelController implements Initializable {
    
    //kontrolki
    @FXML
    private ListView lv_course;
    @FXML
    private ListView lv_cat;
    @FXML
    private TextArea txta_overvw;
    
    //kolekcje rekordów
    private ArrayList<Category> cats;
    private ArrayList<Course> courses;
    private String cat_name = "";
    private String cat_parent = "";
    private Course course_toBePassed = null;
    
    //zapytania
    private final String PScat_fetch = "select * from sbd_tutor.cats"
                                    + " where parent = ?";
    private final String PScourse_fetch = "select * from sbd_tutor.courses"
                                    + " where cat = ?";
    
    @FXML
    private void signOut(ActionEvent event) {
        DBstatement.closeStates();
        //wyczyść kontekst, rozłącz się z bazą i wróć do panelu logowania
        DBcontrol.context_course = null;
        DBcontrol.context_user = null;
        DBcontrol.dbDisconnect();
        SBDproject.changeScene(getClass(), "FXMLsignin.fxml", event);
    }
    
    @FXML
    private void enterCourse(ActionEvent event) {
        if(course_toBePassed == null) return;
        DBstatement.closeStates();
        //stwórz kontekts i idź do panelu przeglądania kursu i lekcji
        DBcontrol.context_course = new Course();
        DBcontrol.context_course.setDescription(course_toBePassed.getDescritpion());
        DBcontrol.context_course.setTitle(course_toBePassed.getTitle());
        DBcontrol.context_course.setCat(course_toBePassed.getCat());
        DBcontrol.context_course.setLessons(course_toBePassed.getLessons());
        DBcontrol.context_course.setAuthor(course_toBePassed.getAuthor());
        SBDproject.changeScene(getClass(), "FXMLeditcourse.fxml", event);
    }
    
    @FXML
    private void showUserAccount(ActionEvent event) {
        //idź do panelu konta użytkownika
        SBDproject.changeScene(getClass(), "FXMLuseraccount.fxml", event);
    }
    
    @FXML
    private void showSubcats(ActionEvent event) {
        //sprawdź zaznaczony obiekt
        String selectedItem = (String) lv_cat.getSelectionModel().getSelectedItem();
        if(selectedItem == null) selectedItem = "";
        //naszym rodzicem będzie zaznaczony obiekt bądź "" czyli root
        cat_parent = selectedItem;
        ObservableList<String> items = FXCollections.observableArrayList();
        //wykonujemy zapytanie
        ArrayList<DBstatement.arg> args = new ArrayList<>();
        args.add(new DBstatement.arg(cat_parent, null, null));
        cats = DBstatement.execFetch("cat", 0, args);
        //wypełniamy kontrolkę danymi
        cats.forEach((u) -> {
            items.add(u.getName());
        });
        lv_cat.setItems(items);
    }
    
    @FXML
    private void showCourselist(ActionEvent event) {
        String selectedItem = (String) lv_cat.getSelectionModel().getSelectedItem();
        if(selectedItem == null) selectedItem = "";
        //zaznaczony rodzic to kategoria naszych kursów
        cat_name = selectedItem;
        ObservableList<String> items = FXCollections.observableArrayList();
        
        //wykonanie zapytania i pobranie rekordów
        ArrayList<DBstatement.arg> args = new ArrayList<>();
        args.add(new DBstatement.arg(cat_name, null, null));
        courses = DBstatement.execFetch("course", 1, args);
        courses.forEach((u) -> {
            items.add(u.getTitle());
        });
        lv_course.setItems(items);
    }
    
    @FXML
    private void showCourseoverview(ActionEvent event) {
        Integer selectedItem = lv_cat.getSelectionModel().getSelectedIndex();
        if(selectedItem < courses.size() && selectedItem >= 0) {
            //
            String text = courses.get(selectedItem).getTitle().toUpperCase() + "\n\n"
                    + "by: " + courses.get(selectedItem).getAuthor() + "\n"
                    + courses.get(selectedItem).getLessons() +" lessons\n\n"
                    + courses.get(selectedItem).getDescritpion();
            txta_overvw.setText(text);
            course_toBePassed = courses.get(selectedItem);
        } else {
            txta_overvw.setText("");
            course_toBePassed = null;
        }
    }
    
    @FXML
    private void getAccess(ActionEvent event) {
        if(course_toBePassed == null) return;
        DBcontrol.context_course = new Course();
        DBcontrol.context_course.setTitle(course_toBePassed.getTitle());
        DBcontrol.context_course.setCat(course_toBePassed.getCat());
        DBcontrol.context_course.setLessons(course_toBePassed.getLessons());
        DBcontrol.context_course.setAuthor(course_toBePassed.getAuthor());
        SBDproject.changeScene(getClass(), "FXMLshopping.fxml", event);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txta_overvw.setEditable(false);
        DBstatement.initStates();
        DBstatement.prepState(PScat_fetch);
        DBstatement.prepState(PScourse_fetch);
    }    
    
}
